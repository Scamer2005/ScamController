package com.craftybridge.app.network

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.craftybridge.app.data.CredentialStore
import com.craftybridge.app.data.ServerConfig
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ActiveRoute { NONE, LAN, TAILSCALE }

sealed interface ConnectionPhase {
    data object Idle : ConnectionPhase
    data class ProbingLan(val url: String) : ConnectionPhase
    data object TriggeringTailscale : ConnectionPhase
    data class WaitingForVpn(val detail: String) : ConnectionPhase
    data class ReadyWebView(val targetUrl: String, val route: ActiveRoute) : ConnectionPhase
    data class ErrorUnreachable(val detail: String, val tailscaleInstalled: Boolean) : ConnectionPhase
}

data class ConnectionUiState(
    val config: ServerConfig,
    val phase: ConnectionPhase = ConnectionPhase.Idle,
    val activeRoute: ActiveRoute = ActiveRoute.NONE,
    val lastLatencyMs: Long? = null,
    val autoLoginAttempts: Int = 0,
    val authStatusMessage: String? = null
)

class ConnectionOrchestrator(application: Application) : AndroidViewModel(application) {

    private val store = CredentialStore(application)
    private val prober = ReachabilityProber()
    private val tailscale = TailscaleManager(application)

    private val _uiState = MutableStateFlow(ConnectionUiState(config = store.load()))
    val uiState: StateFlow<ConnectionUiState> = _uiState.asStateFlow()

    private var connectJob: Job? = null

    init {
        startConnectionSequence()
    }

    fun updateConfig(updated: ServerConfig, reconnectNow: Boolean = true) {
        store.save(updated)
        _uiState.update {
            it.copy(config = updated, autoLoginAttempts = 0, authStatusMessage = null)
        }
        if (reconnectNow) {
            startConnectionSequence()
        }
    }

    fun startConnectionSequence() {
        connectJob?.cancel()
        connectJob = viewModelScope.launch {
            val cfg = _uiState.value.config
            _uiState.update {
                it.copy(
                    autoLoginAttempts = 0,
                    authStatusMessage = null,
                    activeRoute = ActiveRoute.NONE
                )
            }

            // Step 1: Probe Local LAN URL first
            if (cfg.localUrl.isNotBlank()) {
                _uiState.update { it.copy(phase = ConnectionPhase.ProbingLan(cfg.localUrl)) }
                val lanResult = prober.probe(
                    rawUrl = cfg.localUrl,
                    timeoutMs = cfg.lanTimeoutMs,
                    allowSelfSignedCert = cfg.allowSelfSignedCert
                )
                if (lanResult is ProbeResult.Reachable) {
                    _uiState.update {
                        it.copy(
                            phase = ConnectionPhase.ReadyWebView(cfg.localUrl, ActiveRoute.LAN),
                            activeRoute = ActiveRoute.LAN,
                            lastLatencyMs = lanResult.latencyMs
                        )
                    }
                    return@launch
                }
            }

            // Step 2: LAN unreachable — trigger Tailscale VPN broadcast
            if (cfg.tailscaleUrl.isBlank()) {
                _uiState.update {
                    it.copy(
                        phase = ConnectionPhase.ErrorUnreachable(
                            detail = "Local server unreachable and no Tailscale URL configured.",
                            tailscaleInstalled = tailscale.isTailscaleInstalled()
                        )
                    )
                }
                return@launch
            }

            if (!tailscale.isTailscaleInstalled()) {
                _uiState.update {
                    it.copy(
                        phase = ConnectionPhase.ErrorUnreachable(
                            detail = "Tailscale Android app (com.tailscale.ipn) is not installed.",
                            tailscaleInstalled = false
                        )
                    )
                }
                return@launch
            }

            if (!tailscale.isVpnTransportActive()) {
                _uiState.update { it.copy(phase = ConnectionPhase.TriggeringTailscale) }
                tailscale.sendConnectBroadcast()
            }

            _uiState.update {
                it.copy(phase = ConnectionPhase.WaitingForVpn("Connecting Tailscale VPN..."))
            }

            val tsResult = tailscale.waitForVpnAndReachability(
                tailscaleUrl = cfg.tailscaleUrl,
                timeoutMs = cfg.vpnConnectTimeoutMs,
                allowSelfSignedCert = cfg.allowSelfSignedCert,
                prober = prober,
                onStatusTick = { status ->
                    _uiState.update { it.copy(phase = ConnectionPhase.WaitingForVpn(status)) }
                }
            )

            when (tsResult) {
                is ProbeResult.Reachable -> {
                    _uiState.update {
                        it.copy(
                            phase = ConnectionPhase.ReadyWebView(cfg.tailscaleUrl, ActiveRoute.TAILSCALE),
                            activeRoute = ActiveRoute.TAILSCALE,
                            lastLatencyMs = tsResult.latencyMs
                        )
                    }
                }
                is ProbeResult.Unreachable -> {
                    _uiState.update {
                        it.copy(
                            phase = ConnectionPhase.ErrorUnreachable(
                                detail = tsResult.reason,
                                tailscaleInstalled = true
                            )
                        )
                    }
                }
            }
        }
    }

    fun recordAutoLoginAttempt(): Boolean {
        val current = _uiState.value
        if (!current.config.autoLoginEnabled) return false
        if (current.config.username.isBlank() || current.config.password.isBlank()) return false
        if (current.autoLoginAttempts >= 1) {
            _uiState.update {
                it.copy(authStatusMessage = "Auto-login paused after 1 attempt to prevent lockout.")
            }
            return false
        }
        _uiState.update {
            it.copy(
                autoLoginAttempts = it.autoLoginAttempts + 1,
                authStatusMessage = "Submitting saved Crafty credentials..."
            )
        }
        return true
    }

    fun markAuthenticated() {
        _uiState.update { it.copy(authStatusMessage = null) }
    }

    fun disconnectTailscaleVpn() {
        tailscale.sendDisconnectBroadcast()
    }

    fun openTailscaleApp() {
        tailscale.openTailscaleApp()
    }
}
