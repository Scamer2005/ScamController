package com.craftybridge.app.webview

import org.json.JSONObject

object AutoLoginScript {

    fun build(username: String, password: String): String {
        val safeUser = JSONObject.quote(username)
        val safePass = JSONObject.quote(password)

        return """
            (function() {
                if (window.__craftyBridgeSubmitted) return 'already_attempted';
                var attempts = 0;
                var maxAttempts = 20;

                function setNativeValue(el, value) {
                    var descriptor = Object.getOwnPropertyDescriptor(
                        window.HTMLInputElement.prototype,
                        'value'
                    );
                    if (descriptor && descriptor.set) {
                        descriptor.set.call(el, value);
                    } else {
                        el.value = value;
                    }
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                }

                function tryFillAndSubmit() {
                    attempts++;
                    var userEl = document.querySelector('input[name="username"], #username, input[autocomplete="username"]');
                    var passEl = document.querySelector('input[name="password"], #password, input[type="password"]');
                    var submitBtn = document.querySelector('button[type="submit"], input[type="submit"]');

                    if (userEl && passEl && submitBtn) {
                        window.__craftyBridgeSubmitted = true;
                        setNativeValue(userEl, $safeUser);
                        setNativeValue(passEl, $safePass);
                        setTimeout(function() {
                            submitBtn.click();
                        }, 150);
                        return;
                    }
                    if (attempts < maxAttempts) {
                        setTimeout(tryFillAndSubmit, 250);
                    }
                }

                tryFillAndSubmit();
            })();
        """.trimIndent()
    }
}
