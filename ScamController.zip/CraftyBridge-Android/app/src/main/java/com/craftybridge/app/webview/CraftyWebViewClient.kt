package com.craftybridge.app.webview

import android.net.http.SslError
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import com.craftybridge.app.data.ServerConfig
import java.net.URI

class CraftyWebViewClient(
    private val getConfig: () -> ServerConfig,
    private val canAttemptAutoLogin: () -> Boolean,
    private val onAuthenticatedRoute: () -> Unit,
    private val onPageLoadingChanged: (Boolean) -> Unit
) : WebViewClient() {

    override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
        super.onPageStarted(view, url, favicon)
        onPageLoadingChanged(true)
    }

    override fun onPageFinished(view: WebView?, url: String?) {
        super.onPageFinished(view, url)
        onPageLoadingChanged(false)
        CookieManager.getInstance().flush()

        val currentUrl = url ?: return
        val cfg = getConfig()

        if (currentUrl.contains("/login", ignoreCase = true)) {
            if (view != null && canAttemptAutoLogin()) {
                val script = AutoLoginScript.build(cfg.username, cfg.password)
                view.evaluateJavascript(script, null)
            }
        } else {
            onAuthenticatedRoute()
        }
    }

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        return false
    }

    override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
        val cfg = getConfig()
        val failingHost = runCatching { URI(error?.url ?: "").host }.getOrNull()
        val configuredHosts = listOfNotNull(
            runCatching { URI(cfg.localUrl).host }.getOrNull(),
            runCatching { URI(cfg.tailscaleUrl).host }.getOrNull()
        )

        if (cfg.allowSelfSignedCert && failingHost != null &&
            configuredHosts.any { it.equals(failingHost, ignoreCase = true) }
        ) {
            handler?.proceed()
        } else {
            handler?.cancel()
        }
    }
}
