# CraftyBridge Android Client

A native Android (Kotlin + Jetpack Compose + WebView) client for Crafty Controller v4 that:
1. Probes your local LAN Crafty URL first (https://192.168.1.50:8443).
2. Automatically sends `com.tailscale.ipn.CONNECT_VPN` to Tailscale's `IPNReceiver` if the LAN server is unreachable.
3. Waits for Android `TRANSPORT_VPN` and Tailscale endpoint reachability (https://crafty-node.tailnet.ts.net:8443).
4. Opens Crafty Controller in an in-app WebView and automatically logs in using credentials encrypted in `EncryptedSharedPreferences`.

## Setup in Android Studio
1. Open this `CraftyBridge-Android` folder in Android Studio (Ladybug or newer).
2. Let Gradle sync and build the APK (`Build > Build Bundle(s) / APK(s) > Build APK(s)`).
3. On your Android device, install **Tailscale**, sign in once, and set Tailscale Battery Usage to **Unrestricted** so background `CONNECT_VPN` broadcasts work reliably.
4. Launch **CraftyBridge**, tap the Settings icon to enter your Crafty username and password, and tap **Save & Connect**.
